package com.incapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MvcExBookAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
