package com.incapp.mail;

public class MailConstants {
	final static public String ADMIN_EMAIL="incappclassroom23@gmail.com";
	final static public String ADMIN_PASSWORD="qong plaf enjm cuso";
	final static public String RECEIVER_EMAIL="sumitsinghs4848@gmail.com";
}
