package com.incapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MvcExBookAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(MvcExBookAppApplication.class, args);
	}

}
